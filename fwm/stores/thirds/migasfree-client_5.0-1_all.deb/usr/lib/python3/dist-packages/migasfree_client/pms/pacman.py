# Copyright (c) 2021-2026 Jose Antonio Chavarría <jachavar@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import gettext
import logging

from ..utils import ALL_OK, execute, read_file, write_file_if_changed
from .pms import Pms, invalidate_installed_cache

_ = gettext.gettext

__author__ = 'Jose Antonio Chavarría'
__license__ = 'GPLv3'

logger = logging.getLogger('migasfree_client')


@Pms.register('Pacman')
class Pacman(Pms):
    """
    PMS for pacman based systems (Arch, Manjaro, KaOS, ...)
    """

    def __init__(self):
        super().__init__()

        self._name = 'pacman'  # Package Management System name
        self._pms = ['env', 'LC_ALL=C', '/usr/bin/pacman']  # Package Management System command
        self._repo = '/etc/pacman.d/migasfree.list'  # Repositories file
        self._config = '/etc/pacman.conf'
        self._mimetype = [
            'application/x-alpm-package',
            'application/x-zstd-compressed-alpm-package',
            'application/x-gtar',
        ]

        self._pms_key = '/usr/bin/pacman-key'

    @invalidate_installed_cache
    def install(self, package):
        """
        bool install(string package)
        """

        cmd = [*self._pms, '--sync', '--needed', package.strip()]
        logger.debug(' '.join(cmd))

        return execute(cmd)[0] == ALL_OK

    @invalidate_installed_cache
    def remove(self, package):
        """
        bool remove(string package)
        """

        cmd = [*self._pms, '--remove', '--recursive', package.strip()]
        logger.debug(' '.join(cmd))

        return execute(cmd)[0] == ALL_OK

    def search(self, pattern):
        """
        bool search(string pattern)
        """

        cmd = [*self._pms, '--sync', '--search', pattern.strip()]
        logger.debug(' '.join(cmd))

        return execute(cmd)[0] == ALL_OK

    @invalidate_installed_cache
    def update_silent(self):
        """
        (bool, string) update_silent(void)
        """

        cmd = [*self._pms, '--sync', '--refresh', '-uu', '--noconfirm']
        logger.debug(' '.join(cmd))

        _ret, _, _error = execute(cmd, interactive=False, verbose=True)

        return _ret == ALL_OK, _error

    @invalidate_installed_cache
    def _execute_silent(self, action, package_set):
        """
        (bool, string) _execute_silent(string action, list package_set)
        Common logic for install_silent and remove_silent
        """

        if not isinstance(package_set, list):
            return False, f'package_set is not a list: {package_set}'

        installed = self._get_installed_packages()

        if action == 'install':
            package_set = [pkg.strip() for pkg in package_set if pkg.strip() not in installed]
        elif action == 'remove':
            package_set = [pkg.strip() for pkg in package_set if pkg.strip() in installed]

        if not package_set:
            return True, None

        if action == 'install':
            cmd = [*self._pms, '--sync', '--needed', '--noconfirm', *package_set]
        elif action == 'remove':
            cmd = [*self._pms, '--remove', '--recursive', '--noconfirm', *package_set]

        logger.debug(' '.join(cmd))

        _ret, _, _error = execute(cmd, interactive=False, verbose=True)

        return _ret == ALL_OK, _error

    def install_silent(self, package_set):
        """
        (bool, string) install_silent(list package_set)
        """

        return self._execute_silent('install', package_set)

    def remove_silent(self, package_set):
        """
        (bool, string) remove_silent(list package_set)
        """

        return self._execute_silent('remove', package_set)

    def is_installed(self, package):
        """
        bool is_installed(string package)
        """

        return package.strip() in self._get_installed_packages()

    def _get_installed_packages(self):
        """
        set _get_installed_packages(void)
        """

        if self._installed_cache is None:
            self._installed_cache = {pkg.split('_')[0] for pkg in self.query_all()}

        return self._installed_cache

    @invalidate_installed_cache
    def clean_all(self):
        """
        bool clean_all(void)
        """

        cmd = [*self._pms, '--sync', '--clean', '--noconfirm']
        logger.debug(' '.join(cmd))

        return execute(cmd)[0] == ALL_OK

    def query_all(self):
        """
        ordered list query_all(void)
        list format: name_version_architecture.extension

        Note: Extension is standardized to .pkg.tar.zst (pacman default since 2020).
        This format is used as a package identifier, not the actual filename.
        """

        cmd = [*self._pms, '--query', '--info']
        logger.debug(' '.join(cmd))

        _ret, _packages, _ = execute(cmd, interactive=False)
        if _ret != ALL_OK or not _packages:
            return []

        _packages = _packages.strip().split('\n\n')
        _result = []
        for _info in _packages:
            _pkg_info = {}
            _info = _info.splitlines()
            for _item in _info:
                if _item.startswith(('Name', 'Version', 'Architecture')):
                    key, value = _item.strip().split(':', 1)
                    _pkg_info[key.strip()] = value.strip()

            # Extension standardized to .pkg.tar.zst (pacman default)
            _result.append(f'{_pkg_info["Name"]}_{_pkg_info["Version"]}_{_pkg_info["Architecture"]}.pkg.tar.zst')

        return _result

    def _include_config(self):
        # add Include = /etc/pacman.d/migasfree.list in /etc/pacman.conf
        # if not included yet before NOTE pacman-key
        line = f'Include = {self._repo}'
        config = read_file(self._config).decode()
        if line in config:
            return  # nothing to do

        config = config.splitlines()
        substring = 'NOTE: You must run `pacman-key --init` before first using pacman'
        index = [i for i, s in enumerate(config) if substring in s]
        if index[0]:
            config.insert(index[0], line)
            write_file_if_changed(self._config, '\n'.join(config))
        else:
            logger.warning(
                _('Add manually "%s" to file %s inside "options" section as last option') % (line, self._config)
            )

    def create_repos(self, protocol, server, repositories):
        """
        bool create_repos(string protocol, string server, list repositories)
        """

        self._include_config()

        content = ''.join(
            f'{repo.get("source_template").format(protocol=protocol, server=server)}' for repo in repositories
        )
        if not content:
            return True

        return write_file_if_changed(self._repo, content)

    @invalidate_installed_cache
    def import_server_key(self, file_key):
        """
        bool import_server_key(string file_key)
        TODO test
        """

        cmd = [self._pms_key, '--add', file_key]
        logger.debug(' '.join(cmd))

        return execute(cmd)[0] == ALL_OK

    def get_system_architecture(self):
        """
        string get_system_architecture(void)
        """

        cmd = ['uname', '-m']
        logger.debug(' '.join(cmd))

        _ret, _arch, _ = execute(cmd, interactive=False)

        return _arch.strip() if _ret == ALL_OK else ''

    def available_packages(self):
        """
        list available_packages(void)
        """

        cmd = [*self._pms, '--sync', '--search', '--quiet']
        logger.debug(' '.join(cmd))

        _ret, _output, _error = execute(cmd, interactive=False)

        return sorted(_output.strip().splitlines()) if _ret == ALL_OK else []
