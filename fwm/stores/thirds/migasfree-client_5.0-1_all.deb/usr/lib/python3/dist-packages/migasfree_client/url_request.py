# Copyright (c) 2011-2026 Jose Antonio Chavarría <jachavar@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import errno
import gettext
import json
import logging
import os
import ssl
import sys

import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
from requests_toolbelt import MultipartEncoder

from .secure import unwrap, wrap
from .settings import TMP_PATH
from .utils import build_magic, get_mfc_release, read_file, write_file

__author__ = 'Jose Antonio Chavarría'
__license__ = 'GPLv3'

_ = gettext.gettext
logger = logging.getLogger('migasfree_client')


class StrictSSLCompatAdapter(HTTPAdapter):
    """Custom HTTPAdapter that disables strict SSL verification in modern Python versions (e.g., Python 3.13+).
    This is required when using self-signed or legacy internal CA certificates that lack the required
    Key Usage extensions under modern RFC 5280 strict compliance rules.
    """

    def init_poolmanager(self, connections, maxsize, block=False, **kwargs):
        context = ssl.create_default_context()
        if hasattr(ssl, 'VERIFY_X509_STRICT'):
            context.verify_flags &= ~ssl.VERIFY_X509_STRICT
        if hasattr(ssl, 'VERIFY_X509_PARTIAL_CHAIN'):
            context.verify_flags &= ~ssl.VERIFY_X509_PARTIAL_CHAIN
        kwargs['ssl_context'] = context
        return super().init_poolmanager(connections, maxsize, block=block, **kwargs)

    def proxy_manager_for(self, proxy, **kwargs):
        context = ssl.create_default_context()
        if hasattr(ssl, 'VERIFY_X509_STRICT'):
            context.verify_flags &= ~ssl.VERIFY_X509_STRICT
        if hasattr(ssl, 'VERIFY_X509_PARTIAL_CHAIN'):
            context.verify_flags &= ~ssl.VERIFY_X509_PARTIAL_CHAIN
        kwargs['ssl_context'] = context
        return super().proxy_manager_for(proxy, **kwargs)


class UrlRequest:
    __slots__ = (
        '_ca_cert',
        '_cert',
        '_debug',
        '_exit_on_error',
        '_mtls_cert',
        '_mtls_key',
        '_private_key',
        '_project',
        '_proxy',
        '_public_key',
        '_safe',
        '_timeout',
        'session',
    )

    _ok_codes = frozenset(
        [
            requests.codes.ok,
            requests.codes.created,
            requests.codes.moved,
            requests.codes.found,
            requests.codes.temporary_redirect,
            requests.codes.resume,
        ]
    )

    def __init__(
        self,
        debug=False,
        proxy='',
        project='',
        keys=None,
        cert=False,
        mtls_cert=None,
        mtls_key=None,
        ca_cert=None,
        timeout=60,
    ):
        if keys is None:
            keys = {}

        self._debug = debug
        self._safe = True
        self._exit_on_error = True
        self._proxy = proxy
        self._project = project
        self._cert = cert
        self._mtls_cert = mtls_cert
        self._mtls_key = mtls_key
        self._ca_cert = ca_cert
        self._timeout = timeout
        self._private_key = keys.get('private')
        self._public_key = keys.get('public')

        # Initialize session with exponential backoff retry
        self.session = requests.Session()
        retries = Retry(
            total=5,
            backoff_factor=1,
            status_forcelist=[
                requests.codes.internal_server_error,
                requests.codes.bad_gateway,
                requests.codes.service_unavailable,
                requests.codes.gateway_timeout,
            ],
            raise_on_status=False,
        )
        adapter = StrictSSLCompatAdapter(max_retries=retries)
        self.session.mount('https://', adapter)
        self.session.mount('http://', adapter)

        logger.info('SSL certificate: %s', self._cert)
        if self._mtls_cert and self._mtls_key:
            logger.info('mTLS client certificate: %s', self._mtls_cert)
            logger.info('mTLS client key: %s', self._mtls_key)
            if self._ca_cert:
                logger.info('CA certificate for verification: %s', self._ca_cert)

        if self._proxy:
            logger.info('Proxy selected: %s', self._proxy)

    @staticmethod
    def _check_tmp_path():
        if not os.path.exists(TMP_PATH):
            try:
                os.makedirs(TMP_PATH, 0o0777)
            except OSError:
                return False

        return True

    def _build_default_headers(self):
        """Build default headers for HTTP requests."""
        return {
            'user-agent': f'migasfree-client/{get_mfc_release()} {requests.utils.default_user_agent()}',
            'accept-language': os.getenv('LANGUAGE', os.getenv('LANG', 'en')),
        }

    def _setup_request_keys(self, keys):
        """Setup encryption keys from the provided dict."""
        if 'private' in keys:
            self._private_key = keys.get('private')
        if 'public' in keys:
            self._public_key = keys.get('public')

    def _log_request_info(self, url, data, safe, exit_on_error):
        """Log request information for debugging."""
        logger.debug('URL: %s', url)
        logger.debug('URL data: %s', data)
        logger.debug('Safe request: %s', safe)
        logger.debug('Exit on error: %s', exit_on_error)

        if self._private_key:
            logger.info('Private key: %s', self._private_key)
        if self._public_key:
            logger.info('Public key: %s', self._public_key)

    def _build_proxies(self):
        """Build proxy configuration dict if proxy is set."""
        if not self._proxy:
            return None
        return {'http': self._proxy, 'https': self._proxy}

    def _build_mtls_params(self):
        """Build mTLS certificate and verify parameters."""
        if self._mtls_cert and self._mtls_key:
            cert_param = (self._mtls_cert, self._mtls_key)
            verify_param = self._ca_cert if self._ca_cert else False
            return cert_param, verify_param
        return None, False

    # ... existing methods _check_tmp_path, _build_default_headers, _setup_request_keys, _log_request_info, _build_proxies, _build_mtls_params ...
    def _execute_post(self, url, data, headers, proxies, cert_param, verify_param):
        """Execute POST request and handle connection errors.

        Returns:
            On success: requests.Response object
            On error: dict with 'error' key
        """
        try:
            return self.session.post(
                url,
                data=data,
                headers=headers,
                proxies=proxies,
                timeout=self._timeout,
                cert=cert_param,
                verify=verify_param,
            )
        except requests.exceptions.ConnectionError as e:
            logger.error('Connection error: %s', e)
            return {'error': {'info': str(e), 'code': errno.ECONNREFUSED}}
        except requests.exceptions.Timeout as e:
            logger.error('Request timeout: %s', e)
            return {'error': {'info': str(e), 'code': errno.ETIMEDOUT}}
        except requests.exceptions.RequestException as e:
            logger.error('Request error: %s', e)
            return {'error': {'info': str(e), 'code': errno.EIO}}

    def run(self, url, data='', upload_files=None, safe=True, exit_on_error=True, debug=False, keys=None):
        """
        Make an HTTP POST request with signature/encryption support.

        This method wraps data using the migasfree signature/encryption protocol
        when safe=True. It also supports file uploads and mTLS client certificates.

        Args:
            url: The URL to send the request to
            data: Data to send (will be wrapped if safe=True)
            upload_files: List of file paths to upload
            safe: If True, wrap data with signature/encryption
            exit_on_error: If True, exit the program on error
            debug: Enable debug mode
            keys: Optional dict with 'private' and 'public' key paths

        Returns:
            On success: The unwrapped response data
            On error: {'error': {'info': str, 'code': int}}
        """
        self._debug = debug
        self._exit_on_error = exit_on_error

        if keys:
            self._setup_request_keys(keys)

        self._log_request_info(url, data, safe, exit_on_error)

        headers = self._build_default_headers()
        if safe:
            data = json.dumps(
                {'msg': wrap(data, sign_key=self._private_key, encrypt_key=self._public_key), 'project': self._project}
            )
            headers['content-type'] = 'application/json'

        if upload_files:
            data, headers = self._prepare_upload_files(upload_files, data, safe, headers)

        url = url if url.endswith('/') else url + '/'

        proxies = self._build_proxies()
        cert_param, verify_param = self._build_mtls_params()

        result = self._execute_post(url, data, headers, proxies, cert_param, verify_param)

        # Check if _execute_post returned an error dict
        if isinstance(result, dict) and 'error' in result:
            return result

        req = result
        if req.status_code not in self._ok_codes:
            return self._error_response(req, url)

        return self._evaluate_response(req.json(), safe)

    def _prepare_upload_files(self, upload_files, data, safe, headers):
        """Prepare files for multipart upload."""
        my_magic = build_magic()
        files = []

        for _file in upload_files:
            content = read_file(_file)
            tmp_file = os.path.join(TMP_PATH, os.path.basename(_file))
            write_file(tmp_file, content[0:1023])  # only header
            mime = my_magic.file(tmp_file)
            os.remove(tmp_file)
            files.append(('file', (_file, content, mime)))

        logger.debug('URL upload files: %s', files)

        if safe:
            data = json.loads(data)

        fields = data
        fields.update(dict(files))
        data = MultipartEncoder(fields=fields)
        headers['content-type'] = data.content_type

        return data, headers

    def _process_simple_response(self, req, download):
        """Process response from run_simple request.

        Returns:
            dict with 'data'/'content' on success, or 'error' on failure
        """
        # Handle 404 as "not available" (e.g., mTLS service not deployed)
        if req.status_code == requests.codes.not_found:
            logger.debug('Endpoint not available (404)')
            return {'error': {'info': '', 'code': requests.codes.not_found}}

        if req.status_code in self._ok_codes:
            if download:
                return {'data': None, 'content': req.content}
            try:
                return {'data': req.json()}
            except ValueError:
                return {'data': None, 'content': req.content}

        content_type = req.headers.get('content-type', '')
        if 'html' in content_type:
            logger.error('Simple request failed with status %d (HTML response)', req.status_code)
            info = f'HTTP Error {req.status_code}'
        else:
            logger.error('Simple request failed with status %d: %s', req.status_code, req.text)
            info = req.text

        return {'error': {'info': info, 'code': req.status_code}}

    def run_simple(self, url, data=None, json_data=None, headers=None, timeout=None, download=False):
        """
        Make a simple HTTP POST request without signature/encryption logic.

        This method is useful for public endpoints that don't require
        the migasfree signature/encryption protocol.

        Args:
            url: The URL to send the request to
            data: Form data to send (for application/x-www-form-urlencoded)
            json_data: JSON data to send (for application/json)
            headers: Optional additional headers
            timeout: Request timeout in seconds (default: self._timeout)
            download: If True, return raw response content for binary downloads

        Returns:
            dict: On success: {'data': response_data} or {'data': response_data, 'content': bytes}
                  On error: {'error': {'info': str, 'code': int}}
        """
        timeout = timeout if timeout is not None else self._timeout

        request_headers = self._build_default_headers()
        if headers:
            request_headers.update(headers)

        proxies = self._build_proxies()

        logger.debug('Simple request URL: %s', url)
        logger.debug('Simple request data: %s', data)
        logger.debug('Simple request json: %s', json_data)

        try:
            req = self.session.post(
                url,
                data=data,
                json=json_data,
                headers=request_headers,
                proxies=proxies,
                timeout=timeout,
                verify=self._cert if self._cert else False,
            )
            return self._process_simple_response(req, download)

        except requests.exceptions.ConnectionError as e:
            logger.error('Connection error: %s', str(e))
            return {'error': {'info': str(e), 'code': errno.ECONNREFUSED}}
        except requests.exceptions.Timeout as e:
            logger.error('Request timeout: %s', str(e))
            return {'error': {'info': str(e), 'code': errno.ETIMEDOUT}}
        except Exception as e:
            logger.error('Request error: %s', str(e))
            return {'error': {'info': str(e), 'code': errno.EIO}}

    def _evaluate_response(self, json_response, safe=True):
        if safe and 'msg' in json_response:
            response = unwrap(json_response['msg'], decrypt_key=self._private_key, verify_key=self._public_key)
        else:
            response = json_response.get('detail', json_response) if isinstance(json_response, dict) else json_response

        logger.debug('Response text: %s', response)

        return response

    def _error_response(self, request, url):
        logger.error('url_request server error response code: %s', request.status_code)
        content_type = request.headers.get('content-type', '')
        if 'html' not in content_type:
            logger.error('url_request server error response info: %s', request.text)

        content_type = request.headers.get('content-type', '')
        is_json = 'json' in content_type
        info = self._evaluate_response(request.json()) if is_json else request.text

        if self._debug:
            logger.error(_('HTTP error code: %s') % request.status_code)

            if not self._check_tmp_path():
                msg = _('Error creating %s directory') % TMP_PATH
                logger.exception(msg)
                if self._exit_on_error:
                    sys.exit(errno.EPERM)

                return {'error': {'info': msg, 'code': errno.EPERM}}

            extension = 'txt' if is_json else 'html'
            _file = os.path.join(
                TMP_PATH,
                f'response.{request.status_code}.{url.replace("/", ".").replace(":", ".").rstrip(".")}.{extension}',
            )
            write_file(_file, str(info))
            logger.info(_('Error response saved to: %s') % _file)

        if self._exit_on_error:
            if 'html' not in content_type:
                logger.error(_('Error: %s') % info)
            else:
                logger.error(_('Status code: %s') % request.status_code)
            sys.exit(errno.EACCES)

        if 'html' in content_type:
            info = f'HTTP Error {request.status_code}'

        return {'error': {'info': str(info), 'code': request.status_code}}
